package com.example.lab2_java;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.sql.Connection;
import java.util.ResourceBundle;
import java.sql.*;

public class HelloController implements Initializable {
    public TableView<GAME> gametable;
    public TableColumn<GAME, Integer> id;
    public TableColumn<GAME, String> name;
    public TableColumn<GAME, Integer> cost;
    public TableColumn<GAME, Integer> size;
    public TextField uid;
    public TextField uname;
    public TextField ucost;
    public TextField usize;
    @FXML
    private Label welcomeText;
    ObservableList<GAME> list = FXCollections.observableArrayList();


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        id.setCellValueFactory(new
                PropertyValueFactory<GAME, Integer>("id"));
        name.setCellValueFactory(new
                PropertyValueFactory<GAME, String>("name"));
        cost.setCellValueFactory(new
                PropertyValueFactory<GAME, Integer>("cost"));
        size.setCellValueFactory(new
                PropertyValueFactory<GAME, Integer>("size"));
        gametable.setItems(list);
    }

    @FXML
    protected void onHelloButtonClick() {
        populateTable();
    }

    public void populateTable() {
        // Establish a database connection
        String jdbcUrl = "jdbc:mysql://localhost:3306/LAB2_JAVA";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "SELECT * FROM GAME";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            // Populate the table with data from the database
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                int cost = resultSet.getInt("cost");
                int size = resultSet.getInt("size");
                gametable.getItems().add(new GAME(id, name, cost, size));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }


    }

    public void InsertData(ActionEvent actionEvent) {

        String name = uname.getText();
        Integer cost = Integer.valueOf(ucost.getText());
        Integer size = Integer.valueOf(usize.getText());




        String jdbcUrl = "jdbc:mysql://localhost:3306/lab2_java";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "INSERT INTO `GAME`( `name`, `cost`, `size`) VALUES ('"+name+"','"+cost+"','"+size+"')";
            Statement statement = connection.createStatement();
            statement.execute(query);
            // Populate the table with data from the database

        } catch (SQLException e) {
            e.printStackTrace();
        }




    }

    public void UpdateData(ActionEvent actionEvent) {
        Integer id = Integer.valueOf(uid.getText());
        String name = uname.getText();
        Integer cost = Integer.valueOf(ucost.getText());
        Integer size = Integer.valueOf(usize.getText());




        String jdbcUrl = "jdbc:mysql://localhost:3306/lab2_java";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "UPDATE `GAME` SET `name`='"+name+"',`cost`='"+cost+"',`size`='"+size+"' WHERE id='"+id+"' ";
            Statement statement = connection.createStatement();
            statement.execute(query);
            // Populate the table with data from the database

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void DeleteData(ActionEvent actionEvent) {
        Integer id = Integer.valueOf(uid.getText());




        String jdbcUrl = "jdbc:mysql://localhost:3306/lab2_java";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "DELETE FROM `GAME` WHERE id='"+id+"'";
            Statement statement = connection.createStatement();
            statement.execute(query);
            // Populate the table with data from the database

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void LoadData(ActionEvent actionEvent) {
        Integer id = Integer.valueOf(uid.getText());

        String jdbcUrl = "jdbc:mysql://localhost:3306/lab2_java";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "SELECT * FROM GAME WHERE id='"+id+"'";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            // Populate the table with data from the database
            while (resultSet.next()) {

                String name = resultSet.getString("name");
                Integer cost = Integer.valueOf(resultSet.getString("cost"));
                Integer size = Integer.valueOf(resultSet.getString("size"));

                uname.setText(name);
                ucost.setText(String.valueOf(cost));
                usize.setText(String.valueOf(size));

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

