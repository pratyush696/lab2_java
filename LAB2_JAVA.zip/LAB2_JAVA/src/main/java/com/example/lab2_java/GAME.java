package com.example.lab2_java;

public class GAME {
    private int id;
    private String name;
    private int cost;
    private int size;

    public GAME(int id, String name, int cost, int size) {
        this.id = id;
        this.name = name;
        this.cost = cost;
        this.size = size;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }
}
